<?php
/**
 * Plugin Name: CMS SEO — Charbel Msallem Studios
 * Description: City and service pages for SEO, and keeps old 2024 WordPress addresses pointing at the new site (301) after the old pages were removed. Works beside "CMS Site". Deactivate to undo.
 * Version: 1.5.0
 * Author: Charbel Msallem Studios
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

add_action( 'template_redirect', function () {
	if ( is_user_logged_in() || is_admin() || ! is_404() ) { return; }
	$path = trim( (string) wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? $_SERVER['REQUEST_URI'] : '/', PHP_URL_PATH ), '/' );
	if ( '' === $path ) { return; }
	$first = strtolower( strtok( $path, '/' ) );
	$map = array(
		'jewelry'        => '/jewellery.html',
		'contact'        => '/#contact',
		'bookyourshoot'  => '/#contact',
		'video'          => '/#films',
		'clients'        => '/#houses',
		'about'          => '/',
		'photo-2'        => '/',
		'photo'          => '/',
		'fashion-design' => '/',
		'celebrities'    => '/',
		'makeup'         => '/',
	);
	$to = null;
	if ( isset( $map[ $first ] ) ) {
		$to = $map[ $first ];
	} elseif ( preg_match( '/^(20\d\d|category|tag|author|page|blog|_mgl\w*|[0-9a-f]{32})$/i', $first ) ) {
		$to = '/';
	}
	if ( null === $to ) { return; }
	nocache_headers();
	wp_safe_redirect( home_url( $to ), 301 );
	exit;
}, 0 );

/* City and service pages, served from this plugin's pages/ folder. */
add_action( 'init', function () {
	if ( is_admin() || wp_doing_ajax() || wp_doing_cron() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) { return; }
	$method = isset( $_SERVER['REQUEST_METHOD'] ) ? $_SERVER['REQUEST_METHOD'] : 'GET';
	if ( 'GET' !== $method && 'HEAD' !== $method ) { return; }
	$path = trim( (string) wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? $_SERVER['REQUEST_URI'] : '/', PHP_URL_PATH ), '/' );
	$pages = array( 'beirut' => 'beirut.html', 'dubai' => 'dubai.html', 'paris' => 'paris.html', 'milan' => 'milan.html', 'istanbul' => 'istanbul.html', 'barcelona' => 'barcelona.html', 'bridal' => 'bridal.html', 'couture' => 'couture.html', 'fashion-show' => 'fashion-show.html', 'editorial' => 'editorial.html', 'fashion-film' => 'fashion-film.html' );
	if ( ! isset( $pages[ $path ] ) ) { return; }
	$file = __DIR__ . '/pages/' . $pages[ $path ];
	if ( ! is_readable( $file ) ) { return; }
	status_header( 200 );
	header( 'Content-Type: text/html; charset=utf-8' );
	header( 'Cache-Control: public, max-age=300' );
	header( 'X-CMS-SEO: 1.5.0' );
	if ( 'HEAD' !== $method ) { readfile( $file ); }
	exit;
}, 0 );

/*
 * Studio founded 2009 (Charbel's correction, 8 Nov 2026). Every stand-alone "2012" in the
 * CMS Site pages is read as "2009" on the way out (output buffer), so everything else CMS Site
 * and other plugins add stays exactly as it is. Deactivate this plugin to undo.
 */
add_action( 'init', function () {
	if ( is_admin() || wp_doing_ajax() || wp_doing_cron() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) { return; }
	$path = '/' . ltrim( (string) wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? $_SERVER['REQUEST_URI'] : '/', PHP_URL_PATH ), '/' );
	if ( ! in_array( $path, array( '/', '/service.html', '/jewellery.html', '/llms.txt', '/pay', '/pay/', '/terms', '/terms/' ), true ) ) { return; }
	ob_start( function ( $out ) {
		$out = preg_replace( '/(?<![\\d-])2012(?!\\d)/', '2009', $out );
		// Footer city names become links to the city pages.
		$out = preg_replace_callback( '#<div class="cities">(.*?)</div>#s', function ( $m ) {
			$slugs = array( 'Paris' => 'paris', 'Milano' => 'milan', 'Milan' => 'milan', 'Dubai' => 'dubai', 'Istanbul' => 'istanbul', 'Barcelona' => 'barcelona', 'Beirut' => 'beirut' );
			return '<div class="cities">' . preg_replace_callback( '#<span>([^<]+)</span>#', function ( $c ) use ( $slugs ) {
				$n = trim( $c[1] );
				return isset( $slugs[ $n ] ) ? '<span><a href="/' . $slugs[ $n ] . '" style="color:inherit;text-decoration:none">' . $c[1] . '</a></span>' : $c[0];
			}, $m[1] ) . '</div>';
		}, $out );
		return $out;
	} );
}, -10 );

/* Sitemap: add the city pages to the CMS Site sitemap on the way out. */
add_action( 'init', function () {
	$path = '/' . ltrim( (string) wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? $_SERVER['REQUEST_URI'] : '/', PHP_URL_PATH ), '/' );
	if ( '/sitemap.xml' !== $path ) { return; }
	ob_start( function ( $out ) {
		if ( false === strpos( $out, '</urlset>' ) || false !== strpos( $out, '/beirut</loc>' ) ) { return $out; }
		$add = '';
		foreach ( array( 'beirut', 'dubai', 'paris', 'milan', 'istanbul', 'barcelona', 'bridal', 'couture', 'fashion-show', 'editorial', 'fashion-film' ) as $c ) {
			$add .= '  <url><loc>https://charbelmsallem.net/' . $c . '</loc><lastmod>2026-11-08</lastmod></url>' . "\n";
		}
		return str_replace( '</urlset>', $add . '</urlset>', $out );
	} );
}, -10 );
