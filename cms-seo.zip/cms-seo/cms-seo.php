<?php
/**
 * Plugin Name: CMS SEO — Charbel Msallem Studios
 * Description: City and service pages for SEO, and keeps old 2024 WordPress addresses pointing at the new site (301) after the old pages were removed. Works beside "CMS Site". Deactivate to undo.
 * Version: 1.2.0
 * Author: Charbel Msallem Studios
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

add_action( 'template_redirect', function () {
	if ( is_user_logged_in() || is_admin() || ! is_404() ) { return; }
	$path = trim( (string) wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? $_SERVER['REQUEST_URI'] : '/', PHP_URL_PATH ), '/' );
	if ( '' === $path ) { return; }
	$first = strtolower( strtok( $path, '/' ) );
	$map = array(
		'jewelry'        => '/jewellery.html',
		'contact'        => '/#contact',
		'bookyourshoot'  => '/#contact',
		'video'          => '/#films',
		'clients'        => '/#houses',
		'about'          => '/',
		'photo-2'        => '/',
		'photo'          => '/',
		'fashion-design' => '/',
		'celebrities'    => '/',
		'makeup'         => '/',
	);
	$to = null;
	if ( isset( $map[ $first ] ) ) {
		$to = $map[ $first ];
	} elseif ( preg_match( '/^(20\d\d|category|tag|author|page|blog|_mgl\w*|[0-9a-f]{32})$/i', $first ) ) {
		$to = '/';
	}
	if ( null === $to ) { return; }
	nocache_headers();
	wp_safe_redirect( home_url( $to ), 301 );
	exit;
}, 0 );

/* City and service pages, served from this plugin's pages/ folder. */
add_action( 'init', function () {
	if ( is_admin() || wp_doing_ajax() || wp_doing_cron() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) { return; }
	$method = isset( $_SERVER['REQUEST_METHOD'] ) ? $_SERVER['REQUEST_METHOD'] : 'GET';
	if ( 'GET' !== $method && 'HEAD' !== $method ) { return; }
	$path = trim( (string) wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? $_SERVER['REQUEST_URI'] : '/', PHP_URL_PATH ), '/' );
	$pages = array( 'beirut' => 'beirut.html' );
	if ( ! isset( $pages[ $path ] ) ) { return; }
	$file = __DIR__ . '/pages/' . $pages[ $path ];
	if ( ! is_readable( $file ) ) { return; }
	status_header( 200 );
	header( 'Content-Type: text/html; charset=utf-8' );
	header( 'Cache-Control: public, max-age=300' );
	header( 'X-CMS-SEO: 1.2.0' );
	if ( 'HEAD' !== $method ) { readfile( $file ); }
	exit;
}, 0 );

/*
 * Studio founded 2009 (Charbel's correction, 8 Nov 2026). Serves the CMS Site pages with
 * every stand-alone "2012" read as "2009", until CMS Site itself is rebuilt with the new year.
 * Runs just before CMS Site; same visitor rules; deactivate this plugin to undo.
 */
add_action( 'init', function () {
	if ( is_admin() || wp_doing_ajax() || wp_doing_cron() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) { return; }
	$method = isset( $_SERVER['REQUEST_METHOD'] ) ? $_SERVER['REQUEST_METHOD'] : 'GET';
	if ( 'GET' !== $method && 'HEAD' !== $method ) { return; }
	$visitor_keys = array( 'r', 'ref', 'nc', 'v', 'tri', 'fbclid', 'gclid', 'msclkid', 'igshid', 'mc_cid', 'mc_eid' );
	foreach ( array_keys( $_GET ) as $k ) {
		if ( 0 === strpos( (string) $k, 'utm_' ) ) { continue; }
		if ( ! in_array( (string) $k, $visitor_keys, true ) ) { return; }
	}
	$path = '/' . ltrim( (string) wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? $_SERVER['REQUEST_URI'] : '/', PHP_URL_PATH ), '/' );
	if ( '/' !== $path && isset( $_SERVER['HTTP_ACCEPT'] ) && false !== strpos( $_SERVER['HTTP_ACCEPT'], 'application/json' ) && false === strpos( $_SERVER['HTTP_ACCEPT'], 'text/html' ) ) { return; }
	$map = array(
		'/'               => array( 'index.html', 'text/html; charset=utf-8' ),
		'/service.html'   => array( 'service.html', 'text/html; charset=utf-8' ),
		'/jewellery.html' => array( 'jewellery.html', 'text/html; charset=utf-8' ),
		'/llms.txt'       => array( 'llms.txt', 'text/plain; charset=utf-8' ),
	);
	if ( ! isset( $map[ $path ] ) ) { return; }
	$file = WP_PLUGIN_DIR . '/cms-site/site/' . $map[ $path ][0];
	if ( ! is_readable( $file ) ) { return; }
	$html = file_get_contents( $file );
	if ( false === $html ) { return; }
	$html = preg_replace( '/(?<![\d-])2012(?!\d)/', '2009', $html );
	status_header( 200 );
	header( 'Content-Type: ' . $map[ $path ][1] );
	header( 'Cache-Control: public, max-age=300' );
	header( 'X-CMS-SEO: 1.2.0 year' );
	if ( 'HEAD' !== $method ) { echo $html; } // phpcs:ignore
	exit;
}, -10 );
