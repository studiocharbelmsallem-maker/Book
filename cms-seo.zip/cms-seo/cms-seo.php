<?php
/**
 * Plugin Name: CMS SEO — Charbel Msallem Studios
 * Description: City and service pages for SEO, and keeps old 2024 WordPress addresses pointing at the new site (301 for real moves, 410 Gone for junk). Works beside "CMS Site". Deactivate to undo.
 * Version: 1.6.0
 * Author: Charbel Msallem Studios
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

/*
 * Old 2024 WordPress addresses (1.6.0, 8 Nov 2026).
 * Real moves keep a 301 to their new home. Junk (attachment/image pages, hash and _MGL
 * file pages, archives, the placeholder contact, /celebrities, /bookyourshoot and the
 * other dead 2024 pages) answers 410 Gone so Google drops them instead of folding them
 * into the homepage. Only fires on a 404 (or a WordPress attachment page), so any new
 * page built later at the same address (e.g. /about/, /celebrities/) wins automatically.
 */
add_action( 'template_redirect', function () {
	if ( is_user_logged_in() || is_admin() ) { return; }
	$uri   = isset( $_SERVER['REQUEST_URI'] ) ? $_SERVER['REQUEST_URI'] : '/';
	$path  = trim( (string) wp_parse_url( $uri, PHP_URL_PATH ), '/' );
	$query = (string) wp_parse_url( $uri, PHP_URL_QUERY );
	$gone  = false;
	if ( is_attachment() || preg_match( '/(^|&)attachment(_id)?=/i', $query ) || preg_match( '#(^|/)attachment(/|$)#i', $path ) ) {
		$gone = true;
	} elseif ( ! is_404() || '' === $path ) {
		return;
	}
	$first = strtolower( (string) strtok( $path, '/' ) );
	$moved = array(
		'jewelry' => '/jewellery.html',
		'video'   => '/#films',
		'clients' => '/#houses',
	);
	if ( ! $gone && isset( $moved[ $first ] ) ) {
		nocache_headers();
		wp_safe_redirect( home_url( $moved[ $first ] ), 301 );
		exit;
	}
	$dead = array( 'contact', 'bookyourshoot', 'celebrities', 'about', 'photo', 'photo-2', 'fashion-design', 'makeup' );
	if ( ! $gone && ( in_array( $first, $dead, true )
		|| preg_match( '/^(20\d\d|category|tag|author|page|blog|wp-content|_mgl\w*|[0-9a-f]{32}(\.\w+)?)$/i', $first )
		|| preg_match( '/_mgl\d*/i', $path ) ) ) {
		$gone = true;
	}
	if ( ! $gone ) { return; }
	nocache_headers();
	status_header( 410 );
	header( 'X-Robots-Tag: noindex' );
	header( 'Content-Type: text/html; charset=utf-8' );
	header( 'X-CMS-SEO: 1.6.0' );
	echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="robots" content="noindex"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Charbel Msallem Studios</title></head>'
		. '<body style="margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;background:#fff;font-family:Georgia,serif;color:#1a1a1a;text-align:center">'
		. '<div><p style="letter-spacing:.2em;font-size:12px;color:#a8894f">CHARBEL MSALLEM STUDIOS</p><p>This page no longer exists.</p><p><a href="/" style="color:#a8894f">Enter the studio</a></p></div></body></html>';
	exit;
}, 0 );

/* City and service pages, served from this plugin's pages/ folder. */
add_action( 'init', function () {
	if ( is_admin() || wp_doing_ajax() || wp_doing_cron() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) { return; }
	$method = isset( $_SERVER['REQUEST_METHOD'] ) ? $_SERVER['REQUEST_METHOD'] : 'GET';
	if ( 'GET' !== $method && 'HEAD' !== $method ) { return; }
	$path = trim( (string) wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? $_SERVER['REQUEST_URI'] : '/', PHP_URL_PATH ), '/' );
	$pages = array( 'beirut' => 'beirut.html', 'dubai' => 'dubai.html', 'paris' => 'paris.html', 'milan' => 'milan.html', 'istanbul' => 'istanbul.html', 'barcelona' => 'barcelona.html', 'bridal' => 'bridal.html', 'couture' => 'couture.html', 'fashion-show' => 'fashion-show.html', 'editorial' => 'editorial.html', 'fashion-film' => 'fashion-film.html' );
	if ( ! isset( $pages[ $path ] ) ) { return; }
	$file = __DIR__ . '/pages/' . $pages[ $path ];
	if ( ! is_readable( $file ) ) { return; }
	status_header( 200 );
	header( 'Content-Type: text/html; charset=utf-8' );
	header( 'Cache-Control: public, max-age=300' );
	header( 'X-CMS-SEO: 1.6.0' );
	if ( 'HEAD' !== $method ) { readfile( $file ); }
	exit;
}, 0 );

/*
 * Studio founded 2009 (Charbel's correction, 8 Nov 2026). Every stand-alone "2012" in the
 * CMS Site pages is read as "2009" on the way out (output buffer), so everything else CMS Site
 * and other plugins add stays exactly as it is. Deactivate this plugin to undo.
 */
add_action( 'init', function () {
	if ( is_admin() || wp_doing_ajax() || wp_doing_cron() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) { return; }
	$path = '/' . ltrim( (string) wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? $_SERVER['REQUEST_URI'] : '/', PHP_URL_PATH ), '/' );
	if ( ! in_array( $path, array( '/', '/service.html', '/jewellery.html', '/llms.txt', '/pay', '/pay/', '/terms', '/terms/' ), true ) ) { return; }
	ob_start( function ( $out ) {
		$out = preg_replace( '/(?<![\\d-])2012(?!\\d)/', '2009', $out );
		// Footer city names become links to the city pages.
		$out = preg_replace_callback( '#<div class="cities">(.*?)</div>#s', function ( $m ) {
			$slugs = array( 'Paris' => 'paris', 'Milano' => 'milan', 'Milan' => 'milan', 'Dubai' => 'dubai', 'Istanbul' => 'istanbul', 'Barcelona' => 'barcelona', 'Beirut' => 'beirut' );
			return '<div class="cities">' . preg_replace_callback( '#<span>([^<]+)</span>#', function ( $c ) use ( $slugs ) {
				$n = trim( $c[1] );
				return isset( $slugs[ $n ] ) ? '<span><a href="/' . $slugs[ $n ] . '" style="color:inherit;text-decoration:none">' . $c[1] . '</a></span>' : $c[0];
			}, $m[1] ) . '</div>';
		}, $out );
		// A slim strip above the footer: the six cities and the services, each a page of its own.
		if ( false === strpos( $out, 'id="cms-pages"' ) && false !== strpos( $out, '<footer class="foot">' ) ) {
			$c = array( 'beirut' => 'Beirut', 'dubai' => 'Dubai', 'paris' => 'Paris', 'milan' => 'Milano', 'istanbul' => 'Istanbul', 'barcelona' => 'Barcelona' );
			$v = array( 'bridal' => 'Bridal', 'couture' => 'Couture', 'fashion-show' => 'Fashion show', 'editorial' => 'Editorial', 'fashion-film' => 'Fashion film', 'jewellery.html' => 'Jewellery' );
			$a = function ( $arr ) { $h = ''; foreach ( $arr as $k => $n ) { $h .= '<a href="/' . $k . '">' . $n . '</a>'; } return $h; };
			$strip = '<section id="cms-pages" style="padding:56px 20px;text-align:center;border-top:1px solid rgba(154,123,46,.28)"><style>#cms-pages .k{font:500 11px/1 Archivo,Helvetica,Arial,sans-serif;letter-spacing:.28em;text-transform:uppercase;color:#7E6424;margin:0 0 16px}#cms-pages .r{display:flex;flex-wrap:wrap;justify-content:center;gap:10px 26px;margin:0 auto 34px;max-width:900px}#cms-pages .r a{font:400 22px/1.3 "EB Garamond",Garamond,Georgia,serif;color:#1E1C18;text-decoration:none;border-bottom:1px solid transparent}#cms-pages .r a:hover{border-color:#9A7B2E}</style><p class="k">The cities</p><div class="r">' . $a( $c ) . '</div><p class="k">The work</p><div class="r">' . $a( $v ) . '</div></section>';
			$out = str_replace( '<footer class="foot">', $strip . "\n" . '<footer class="foot">', $out );
		}
		return $out;
	} );
}, -10 );

/* Sitemap: add the city pages to the CMS Site sitemap on the way out. */
add_action( 'init', function () {
	$path = '/' . ltrim( (string) wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? $_SERVER['REQUEST_URI'] : '/', PHP_URL_PATH ), '/' );
	if ( '/sitemap.xml' !== $path ) { return; }
	ob_start( function ( $out ) {
		if ( false === strpos( $out, '</urlset>' ) || false !== strpos( $out, '/beirut</loc>' ) ) { return $out; }
		$add = '';
		foreach ( array( 'beirut', 'dubai', 'paris', 'milan', 'istanbul', 'barcelona', 'bridal', 'couture', 'fashion-show', 'editorial', 'fashion-film' ) as $c ) {
			$add .= '  <url><loc>https://charbelmsallem.net/' . $c . '</loc><lastmod>2026-11-08</lastmod></url>' . "\n";
		}
		return str_replace( '</urlset>', $add . '</urlset>', $out );
	} );
}, -10 );
