<?php
/**
 * Plugin Name: CMS SEO — Charbel Msallem Studios
 * Description: City and service pages for SEO, and keeps old 2024 WordPress addresses pointing at the new site (301 for real moves, 410 Gone for junk). Works beside "CMS Site". Deactivate to undo.
 * Version: 1.9.16
 * Author: Charbel Msallem Studios
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

/*
 * Old 2024 WordPress addresses (1.6.0, 8 Nov 2026).
 * Real moves keep a 301 to their new home. Junk (attachment/image pages, hash and _MGL
 * file pages, archives, the placeholder contact, /celebrities, /bookyourshoot and the
 * other dead 2024 pages) answers 410 Gone so Google drops them instead of folding them
 * into the homepage. Only fires on a 404 (or a WordPress attachment page), so any new
 * page built later at the same address (e.g. /about/, /celebrities/) wins automatically.
 */
add_action( 'template_redirect', function () {
	if ( is_user_logged_in() || is_admin() ) { return; }
	$uri   = isset( $_SERVER['REQUEST_URI'] ) ? $_SERVER['REQUEST_URI'] : '/';
	$path  = trim( (string) wp_parse_url( $uri, PHP_URL_PATH ), '/' );
	$query = (string) wp_parse_url( $uri, PHP_URL_QUERY );
	$gone  = false;
	if ( is_attachment() || preg_match( '/(^|&)attachment(_id)?=/i', $query ) || preg_match( '#(^|/)attachment(/|$)#i', $path ) ) {
		$gone = true;
	} elseif ( ! is_404() || '' === $path ) {
		return;
	}
	$first = strtolower( (string) strtok( $path, '/' ) );
	$moved = array(
		'jewelry' => '/jewellery',
		'video'   => '/#films',
		'clients' => '/#houses',
	);
	if ( ! $gone && isset( $moved[ $first ] ) ) {
		nocache_headers();
		wp_safe_redirect( home_url( $moved[ $first ] ), 301 );
		exit;
	}
	$dead = array( 'contact', 'bookyourshoot', 'celebrities', 'about', 'photo', 'photo-2', 'fashion-design', 'makeup' );
	if ( ! $gone && ( in_array( $first, $dead, true )
		|| preg_match( '/^(20\d\d|category|tag|author|page|blog|wp-content|_mgl\w*|[0-9a-f]{32}(\.\w+)?)$/i', $first )
		|| preg_match( '/_mgl\d*/i', $path ) ) ) {
		$gone = true;
	}
	if ( ! $gone ) { return; }
	nocache_headers();
	status_header( 410 );
	header( 'X-Robots-Tag: noindex' );
	header( 'Content-Type: text/html; charset=utf-8' );
	header( 'X-CMS-SEO: 1.9.16' );
	echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="robots" content="noindex"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Charbel Msallem Studios</title></head>'
		. '<body style="margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;background:#fff;font-family:Georgia,serif;color:#1a1a1a;text-align:center">'
		. '<div><p style="letter-spacing:.2em;font-size:12px;color:#a8894f">CHARBEL MSALLEM STUDIOS</p><p>This page no longer exists.</p><p><a href="/" style="color:#a8894f">Enter the studio</a></p></div></body></html>';
	exit;
}, 0 );

/* City and service pages, served from this plugin's pages/ folder. */
add_action( 'init', function () {
	if ( is_admin() || wp_doing_ajax() || wp_doing_cron() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) { return; }
	$method = isset( $_SERVER['REQUEST_METHOD'] ) ? $_SERVER['REQUEST_METHOD'] : 'GET';
	if ( 'GET' !== $method && 'HEAD' !== $method ) { return; }
	$path = trim( (string) wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? $_SERVER['REQUEST_URI'] : '/', PHP_URL_PATH ), '/' );
	$pages = array( 'beirut' => 'beirut.html', 'dubai' => 'dubai.html', 'paris' => 'paris.html', 'milan' => 'milan.html', 'istanbul' => 'istanbul.html', 'barcelona' => 'barcelona.html', 'bridal' => 'bridal.html', 'couture' => 'couture.html', 'fashion-show' => 'fashion-show.html', 'paris-fashion-week' => 'paris-fashion-week.html', 'fr/paris-fashion-week' => 'fr-paris-fashion-week.html', 'editorial' => 'editorial.html', 'fashion-film' => 'fashion-film.html', 'fr/paris' => 'fr-paris.html', 'ar/beirut' => 'ar-beirut.html', 'ar/dubai' => 'ar-dubai.html', 'celebrities' => 'celebrities.html', 'fr/celebrities' => 'fr-celebrities.html', 'elie-feghali-la-grace' => 'elie-feghali-la-grace.html', 'about' => 'about.html' );
	if ( ! isset( $pages[ $path ] ) ) { return; }
	$file = __DIR__ . '/pages/' . $pages[ $path ];
	if ( ! is_readable( $file ) ) { return; }
	status_header( 200 );
	header( 'Content-Type: text/html; charset=utf-8' );
	header( 'Cache-Control: public, max-age=300' );
	header( 'X-CMS-SEO: 1.9.16' );
	if ( 'HEAD' !== $method ) { readfile( $file ); }
	exit;
}, 0 );

/*
 * Studio founded 2009 (Charbel's correction, 8 Nov 2026). Every stand-alone "2012" in the
 * CMS Site pages is read as "2009" on the way out (output buffer), so everything else CMS Site
 * and other plugins add stays exactly as it is. Deactivate this plugin to undo.
 */
add_action( 'init', function () {
	if ( is_admin() || wp_doing_ajax() || wp_doing_cron() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) { return; }
	$path = '/' . ltrim( (string) wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? $_SERVER['REQUEST_URI'] : '/', PHP_URL_PATH ), '/' );
	if ( ! in_array( $path, array( '/', '/maison-service', '/jewellery', '/llms.txt', '/pay', '/pay/', '/terms', '/terms/' ), true ) ) { return; }
	ob_start( function ( $out ) {
		$out = preg_replace( '/(?<![\\d-])2012(?!\\d)/', '2009', $out );
		// Footer city names become links to the city pages.
		$out = preg_replace_callback( '#<div class="cities">(.*?)</div>#s', function ( $m ) {
			$slugs = array( 'Paris' => 'paris', 'Milano' => 'milan', 'Milan' => 'milan', 'Dubai' => 'dubai', 'Istanbul' => 'istanbul', 'Barcelona' => 'barcelona', 'Beirut' => 'beirut' );
			return '<div class="cities">' . preg_replace_callback( '#<span>([^<]+)</span>#', function ( $c ) use ( $slugs ) {
				$n = trim( $c[1] );
				return isset( $slugs[ $n ] ) ? '<span><a href="/' . $slugs[ $n ] . '" style="color:inherit;text-decoration:none">' . $c[1] . '</a></span>' : $c[0];
			}, $m[1] ) . '</div>';
		}, $out );
		// A slim strip above the footer: the six cities and the services, each a page of its own.
		if ( false === strpos( $out, 'id="cms-pages"' ) && false !== strpos( $out, '<footer class="foot">' ) ) {
			$c = array( 'beirut' => 'Beirut', 'dubai' => 'Dubai', 'paris' => 'Paris', 'milan' => 'Milano', 'istanbul' => 'Istanbul', 'barcelona' => 'Barcelona' );
			$v = array( 'bridal' => 'Bridal', 'couture' => 'Couture', 'fashion-show' => 'Fashion show', 'editorial' => 'Editorial', 'fashion-film' => 'Fashion film', 'jewellery' => 'Jewellery', 'celebrities' => 'Celebrities' );
			$a = function ( $arr ) { $h = ''; foreach ( $arr as $k => $n ) { $h .= '<a href="/' . $k . '">' . $n . '</a>'; } return $h; };
			$strip = '<section id="cms-pages" style="padding:56px 20px;text-align:center;border-top:1px solid rgba(154,123,46,.28)"><style>#cms-pages .k{font:500 11px/1 Archivo,Helvetica,Arial,sans-serif;letter-spacing:.28em;text-transform:uppercase;color:#7E6424;margin:0 0 16px}#cms-pages .r{display:flex;flex-wrap:wrap;justify-content:center;gap:10px 26px;margin:0 auto 34px;max-width:900px}#cms-pages .r a{font:400 22px/1.3 "EB Garamond",Garamond,Georgia,serif;color:#1E1C18;text-decoration:none;border-bottom:1px solid transparent}#cms-pages .r a:hover{border-color:#9A7B2E}</style><p class="k">The cities</p><div class="r">' . $a( $c ) . '</div><p class="k">The work</p><div class="r">' . $a( $v ) . '</div><p class="k" style="margin:0"><a href="/about" style="color:inherit;text-decoration:none">About Charbel Msallem</a></p></section>';
			$out = str_replace( '<footer class="foot">', $strip . "\n" . '<footer class="foot">', $out );
		}
		return $out;
	} );
}, -10 );

/* Sitemap: add the city pages to the CMS Site sitemap on the way out. */
add_action( 'init', function () {
	$path = '/' . ltrim( (string) wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? $_SERVER['REQUEST_URI'] : '/', PHP_URL_PATH ), '/' );
	if ( '/sitemap.xml' !== $path ) { return; }
	ob_start( function ( $out ) {
		if ( false === strpos( $out, '</urlset>' ) || false !== strpos( $out, '/beirut</loc>' ) ) { return $out; }
		$add = '';
		foreach ( array( 'beirut', 'dubai', 'paris', 'fr/paris', 'milan', 'istanbul', 'barcelona', 'bridal', 'couture', 'fashion-show', 'paris-fashion-week', 'fr/paris-fashion-week', 'editorial', 'fashion-film', 'celebrities', 'fr/celebrities', 'elie-feghali-la-grace', 'about' ) as $c ) {
			$add .= '  <url><loc>https://charbelmsallem.net/' . $c . '</loc><lastmod>2026-11-08</lastmod></url>' . "\n";
		}
		return str_replace( '</urlset>', $add . '</urlset>', $out );
	} );
}, -10 );

/*
 * 1.7.0 (8 Nov 2026): entity, headings and alt text, on the way out, for the home page,
 * service/jewellery pages and every city/service page above. Nothing in CMS Site is edited.
 *  - Schema: alternateName "Charbel Moussallem", full sameAs, press as subjectOf,
 *    founded 2009, studio address Bsalim (matches the Google Business Profile).
 *  - Chapter H2s get a real space between city and line ("Beirut Where…").
 *  - One written alt per frame from alts.json (keyed by file name).
 */
add_action( 'init', function () {
	if ( is_admin() || wp_doing_ajax() || wp_doing_cron() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) { return; }
	$path = trim( (string) wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? $_SERVER['REQUEST_URI'] : '/', PHP_URL_PATH ), '/' );
	$ok = array( '', 'maison-service', 'jewellery', 'beirut', 'dubai', 'paris', 'milan', 'istanbul', 'barcelona', 'bridal', 'couture', 'fashion-show', 'paris-fashion-week', 'fr/paris-fashion-week', 'editorial', 'fashion-film', 'fr/paris', 'celebrities', 'fr/celebrities', 'elie-feghali-la-grace', 'about' );
	if ( ! in_array( $path, $ok, true ) ) { return; }
	ob_start( function ( $out ) {
		if ( false === stripos( $out, '<html' ) ) { return $out; }
		// Headings: city and line read as two words.
		$out = str_replace( '</span><span class="et">', '</span> <span class="et">', $out );
		// Alt text, one per frame.
		static $alts = null;
		if ( null === $alts ) {
			$f = __DIR__ . '/alts.json';
			$alts = is_readable( $f ) ? (array) json_decode( (string) file_get_contents( $f ), true ) : array();
		}
		if ( $alts && false === strpos( $out, '<html lang="fr"' ) ) {
			$out = preg_replace_callback( '#<img\b[^>]*>#i', function ( $m ) use ( $alts ) {
				$tag = $m[0];
				if ( ! preg_match( '#\ssrc="([^"]+)"#i', $tag, $s ) ) { return $tag; }
				$b = basename( (string) wp_parse_url( $s[1], PHP_URL_PATH ) );
				if ( empty( $alts[ $b ] ) ) { return $tag; }
				$alt = esc_attr( $alts[ $b ] );
				if ( preg_match( '#\salt="[^"]*"#i', $tag ) ) { return preg_replace( '#\salt="[^"]*"#i', ' alt="' . $alt . '"', $tag, 1 ); }
				return preg_replace( '#<img\b#i', '<img alt="' . $alt . '"', $tag, 1 );
			}, $out );
		}
		// Tracking: Google tag (GA4, GTM-KVHFHNK6) + Meta Pixel, once per page, and one event per segment on every action link.
		if ( false === strpos( $out, 'GTM-KVHFHNK6' ) && false !== stripos( $out, '</head>' ) ) {
			$px  = ( false === strpos( $out, "fbq('init'" ) && false === strpos( $out, 'fbq("init"' ) )
				? "!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,document,'script','https://connect.facebook.net/en_US/fbevents.js');fbq('init','454398224725918');fbq('track','PageView');"
				: '';
			$tag = '<script async src="https://www.googletagmanager.com/gtm.js?id=GTM-KVHFHNK6"></script>'
				. '<script>window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}gtag("js",new Date());' . $px
				. '(function(){var p=location.pathname.replace(/^\/|\/$|\.html$/g,"").replace("fr/","")||"home";'
				. 'var seg={bridal:"bridal",couture:"couture","fashion-show":"fashion_show","paris-fashion-week":"fashion_show",editorial:"editorial","fashion-film":"fashion_film",celebrities:"celebrities",jewellery:"jewellery",service:"service",about:"about",home:"home"}[p]||("city_"+p);'
				. 'document.addEventListener("click",function(e){var a=e.target.closest&&e.target.closest("a,button");if(!a)return;var h=(a.getAttribute("href")||"")+" "+(a.textContent||"");'
				. 'if(!/wa\.me|whatsapp|mailto:|tel:|#contact|reserve|book|concept|conversation|begin/i.test(h))return;var ev="lead_"+seg;'
				. 'var m=/wa\.me|whatsapp/i.test(h)?"whatsapp":/cal\.com|concept|book/i.test(h)?"booking":/mailto:/i.test(h)?"email":/tel:/i.test(h)?"call":"contact";try{gtag("event",ev,{link_url:a.href||"",page:p});}catch(x){}try{gtag("event","generate_lead",{method:m,segment:seg,link_url:a.href||"",page:p});}catch(x){}try{window.fbq&&fbq("trackCustom",ev,{page:p});fbq&&fbq("track","Contact");}catch(x){}},true);})();</script>';
			$out = preg_replace( '#</head>#i', $tag . '</head>', $out, 1 );
		}
		// Structured data.
		$same = array(
			'https://www.instagram.com/charbelmsallemstudios/',
			'https://www.facebook.com/249365978439146',
			'https://www.linkedin.com/in/charbel-msallem-49669363/',
			'https://www.threads.net/@charbelmsallemstudios',
			'https://www.pinterest.com/charbelmsallem/',
			'https://www.tiktok.com/@charbelmsallemstu',
			'https://www.youtube.com/channel/UC0-dxrM_ReODRQGYZQCBHRw',
			'https://www.flickr.com/photos/95355285@N03/',
		);
		$press = array(
			array( '@type' => 'NewsArticle', 'url' => 'https://arabic.cnn.com/style/article/2026/10/19/reem-al-jesmi-brings-emirati-heritage-to-milan', 'publisher' => array( '@type' => 'Organization', 'name' => 'CNN Arabic' ) ),
			array( '@type' => 'Article', 'url' => 'https://lofficielmonaco.com/men/the-man-the-muse-the-music-meet-aziz-abdo/', 'publisher' => array( '@type' => 'Organization', 'name' => "L'Officiel Monaco" ) ),
		);
		$out = preg_replace_callback( '#(<script type="application/ld\+json">)(.*?)(</script>)#s', function ( $m ) use ( $same, $press ) {
			$d = json_decode( $m[2], true );
			if ( ! is_array( $d ) ) { return $m[0]; }
			$fix = function ( &$n ) use ( $same, $press ) {
				if ( ! is_array( $n ) ) { return; }
				$t = isset( $n['@type'] ) ? (array) $n['@type'] : array();
				$name = isset( $n['name'] ) ? $n['name'] : '';
				if ( 'Charbel Msallem Studios' === $name ) {
					$n['alternateName'] = array( 'Charbel Moussallem Studios', 'Charbel Moussallem' );
					$n['foundingDate']  = '2009';
					$n['sameAs']        = $same;
					$n['subjectOf']     = $press;
					$n['address']       = array( '@type' => 'PostalAddress', 'streetAddress' => 'Mezher main road, Gymkata building, floor -2', 'addressLocality' => 'Bsalim', 'addressRegion' => 'Mount Lebanon', 'addressCountry' => 'LB' );
				} elseif ( in_array( 'Person', $t, true ) && 'Charbel Msallem' === $name ) {
					$n['alternateName'] = 'Charbel Moussallem';
					$n['sameAs']        = $same;
				}
			};
			if ( isset( $d['@graph'] ) && is_array( $d['@graph'] ) ) {
				foreach ( $d['@graph'] as &$n ) {
					$fix( $n );
					if ( isset( $n['founder'] ) ) { $fix( $n['founder'] ); }
				}
				unset( $n );
			} else {
				$fix( $d );
			}
			return $m[1] . wp_json_encode( $d, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . $m[3];
		}, $out );
		return $out;
	} );
}, -9 );

/*
 * 1.7.3: links to the home page carrying ad/tracking tags (fbclid, gclid, utm_*…) must open
 * the book, not the old WordPress home. Strip only those keys from $_GET before CMS Site
 * decides what to serve; the browser URL keeps them, so GA4 and the Pixel still read them.
 */
add_action( 'init', function () {
	$path = trim( (string) wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? $_SERVER['REQUEST_URI'] : '/', PHP_URL_PATH ), '/' );
	if ( '' !== $path || empty( $_GET ) ) { return; }
	foreach ( array_keys( $_GET ) as $k ) {
		if ( preg_match( '/^(utm_\w+|fbclid|gclid|gbraid|wbraid|msclkid|ttclid|igshid|mc_\w+|ref|cb|_ga|_gl)$/i', $k ) ) { unset( $_GET[ $k ] ); }
	}
}, -100 );
