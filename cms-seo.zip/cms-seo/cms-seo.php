<?php
/**
 * Plugin Name: CMS SEO — Charbel Msallem Studios
 * Description: City and service pages for SEO, and keeps old 2024 WordPress addresses pointing at the new site (301 for real moves, 410 Gone for junk). Works beside "CMS Site". Deactivate to undo.
 * Version: 1.9.53
 * Author: Charbel Msallem Studios
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

/*
 * Old 2024 WordPress addresses (1.6.0, 8 Nov 2026).
 * Real moves keep a 301 to their new home. Junk (attachment/image pages, hash and _MGL
 * file pages, archives, the placeholder contact, /celebrities, /bookyourshoot and the
 * other dead 2024 pages) answers 410 Gone so Google drops them instead of folding them
 * into the homepage. Only fires on a 404 (or a WordPress attachment page), so any new
 * page built later at the same address (e.g. /about/, /celebrities/) wins automatically.
 */
add_action( 'template_redirect', function () {
	if ( is_user_logged_in() || is_admin() ) { return; }
	$uri   = isset( $_SERVER['REQUEST_URI'] ) ? $_SERVER['REQUEST_URI'] : '/';
	$path  = trim( (string) wp_parse_url( $uri, PHP_URL_PATH ), '/' );
	$query = (string) wp_parse_url( $uri, PHP_URL_QUERY );
	$gone  = false;
	if ( preg_match( '#^[0-9a-f]{32}(-\d+)?(/|$)#i', $path ) || is_attachment() || preg_match( '/(^|&)attachment(_id)?=/i', $query ) || preg_match( '#(^|/)attachment(/|$)#i', $path ) ) {
		$gone = true;
	} elseif ( ! is_404() || '' === $path ) {
		return;
	}
	$first = strtolower( (string) strtok( $path, '/' ) );
	$moved = array(
		'jewelry' => '/jewellery',
		'video'   => '/#films',
		'clients' => '/#houses',
	);
	if ( ! $gone && isset( $moved[ $first ] ) ) {
		nocache_headers();
		wp_safe_redirect( home_url( $moved[ $first ] ), 301 );
		exit;
	}
	$dead = array( 'contact', 'bookyourshoot', 'celebrities', 'about', 'photo', 'photo-2', 'fashion-design', 'makeup' );
	if ( ! $gone && ( in_array( $first, $dead, true )
		|| preg_match( '/^(20\d\d|category|tag|author|page|blog|wp-content|_mgl\w*|[0-9a-f]{32}(\.\w+)?)$/i', $first )
		|| preg_match( '/_mgl\d*/i', $path ) ) ) {
		$gone = true;
	}
	if ( ! $gone ) { return; }
	nocache_headers();
	status_header( 410 );
	header( 'X-Robots-Tag: noindex' );
	header( 'Content-Type: text/html; charset=utf-8' );
	header( 'X-CMS-SEO: 1.9.53' );
	echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="robots" content="noindex"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Charbel Msallem Studios</title></head>'
		. '<body style="margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;background:#fff;font-family:Georgia,serif;color:#1a1a1a;text-align:center">'
		. '<div><p style="letter-spacing:.2em;font-size:12px;color:#a8894f">CHARBEL MSALLEM STUDIOS</p><p>This page no longer exists.</p><p><a href="/" style="color:#a8894f">Enter the studio</a></p></div></body></html>';
	exit;
}, 0 );

/* City and service pages, served from this plugin's pages/ folder. 1.9.47: /celebrities gets a Portfolio photoshoots section. 1.9.46: /about rewritten as the entity page; /lebanon-fashion-photographer and /lookbook-photographer-beirut added (sitemap, entity pass). */
add_action( 'init', function () {
	if ( is_admin() || wp_doing_ajax() || wp_doing_cron() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) { return; }
	$method = isset( $_SERVER['REQUEST_METHOD'] ) ? $_SERVER['REQUEST_METHOD'] : 'GET';
	if ( 'GET' !== $method && 'HEAD' !== $method ) { return; }
	$path = trim( (string) wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? $_SERVER['REQUEST_URI'] : '/', PHP_URL_PATH ), '/' );
	$pages = array( 'beirut' => 'beirut.html', 'dubai' => 'dubai.html', 'paris' => 'paris.html', 'milan' => 'milan.html', 'istanbul' => 'istanbul.html', 'barcelona' => 'barcelona.html', 'bridal' => 'bridal.html', 'abaya' => 'abaya.html', 'fr/abaya' => 'fr-abaya.html', 'ar/abaya' => 'ar-abaya.html', 'couture' => 'couture.html', 'fashion-show' => 'fashion-show.html', 'paris-fashion-week' => 'paris-fashion-week.html', 'fr/paris-fashion-week' => 'fr-paris-fashion-week.html', 'editorial' => 'editorial.html', 'fashion-film' => 'fashion-film.html', 'fr/paris' => 'fr-paris.html', 'ar/beirut' => 'ar-beirut.html', 'ar/dubai' => 'ar-dubai.html', 'fr/joaillerie' => 'fr-joaillerie.html', 'celebrities' => 'celebrities.html', 'fr/celebrities' => 'fr-celebrities.html', 'elie-feghali-la-grace' => 'elie-feghali-la-grace.html', 'elie-saab' => 'elie-saab.html', 'about' => 'about.html', 'lebanon-fashion-photographer' => 'lebanon-fashion-photographer.html', 'lookbook-photographer-beirut' => 'lookbook-photographer-beirut.html', 'press' => 'press.html', 'privacy' => 'privacy.html', 'behind-the-scenes' => 'behind-the-scenes.html', 'journal' => 'journal.html', 'journal/golden-ratio-couture-frame' => 'journal-golden-ratio-couture-frame.html', 'journal/light-behind-the-embroidery' => 'journal-light-behind-the-embroidery.html', 'journal/the-night-of-the-show' => 'journal-the-night-of-the-show.html', 'journal/from-beirut-to-the-opera-garnier' => 'journal-from-beirut-to-the-opera-garnier.html', 'journal/fashion-film-or-photographs-couture-launch' => 'journal-fashion-film-or-photographs-couture-launch.html', 'journal/choosing-a-film-director-paris-couture-campaign' => 'journal-choosing-a-film-director-paris-couture-campaign.html', 'journal/one-campaign-three-cities-choosing-the-studio' => 'journal-one-campaign-three-cities-choosing-the-studio.html', 'journal/feed.xml' => 'journal-feed.xml', 'search' => 'search.html', 'aleph' => 'aleph.html' );
	if ( ! isset( $pages[ $path ] ) ) { return; }
	$file = __DIR__ . '/pages/' . $pages[ $path ];
	if ( ! is_readable( $file ) ) { return; }
	status_header( 200 );
	header( '.xml' === substr( $file, -4 ) ? 'Content-Type: application/rss+xml; charset=utf-8' : 'Content-Type: text/html; charset=utf-8' );
	header( 'Cache-Control: public, max-age=300' );
	header( 'X-CMS-SEO: 1.9.53' );
	if ( 'HEAD' !== $method ) { readfile( $file ); }
	exit;
}, 0 );

/*
 * Studio founded 2009 (Charbel's correction, 8 Nov 2026). Every stand-alone "2012" in the
 * CMS Site pages is read as "2009" on the way out (output buffer), so everything else CMS Site
 * and other plugins add stays exactly as it is. Deactivate this plugin to undo.
 */
add_action( 'init', function () {
	if ( is_admin() || wp_doing_ajax() || wp_doing_cron() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) { return; }
	$path = '/' . ltrim( (string) wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? $_SERVER['REQUEST_URI'] : '/', PHP_URL_PATH ), '/' );
	if ( ! in_array( $path, array( '/', '/maison-service', '/jewellery', '/llms.txt', '/pay', '/pay/', '/terms', '/terms/' ), true ) ) { return; }
	ob_start( function ( $out ) {
		$out = preg_replace( '/(?<![\\d-])2012(?!\\d)/', '2009', $out );
		// Footer city names become links to the city pages.
		$out = preg_replace_callback( '#<div class="cities">(.*?)</div>#s', function ( $m ) {
			$slugs = array( 'Paris' => 'paris', 'Milano' => 'milan', 'Milan' => 'milan', 'Dubai' => 'dubai', 'Istanbul' => 'istanbul', 'Barcelona' => 'barcelona', 'Beirut' => 'beirut' );
			return '<div class="cities">' . preg_replace_callback( '#<span>([^<]+)</span>#', function ( $c ) use ( $slugs ) {
				$n = trim( $c[1] );
				return isset( $slugs[ $n ] ) ? '<span><a href="/' . $slugs[ $n ] . '" style="color:inherit;text-decoration:none">' . $c[1] . '</a></span>' : $c[0];
			}, $m[1] ) . '</div>';
		}, $out );
		// A slim strip above the footer: the six cities and the services, each a page of its own.
		if ( false === strpos( $out, 'id="cms-pages"' ) && false !== strpos( $out, '<footer class="foot">' ) ) {
			$c = array( 'beirut' => 'Beirut', 'dubai' => 'Dubai', 'paris' => 'Paris', 'milan' => 'Milano', 'istanbul' => 'Istanbul', 'barcelona' => 'Barcelona' );
			$v = array( 'bridal' => 'Bridal', 'abaya' => 'Abaya', 'couture' => 'Couture', 'fashion-show' => 'Fashion show', 'editorial' => 'Editorial', 'fashion-film' => 'Fashion film', 'jewellery' => 'Jewellery', 'celebrities' => 'Celebrities' );
			$a = function ( $arr ) { $h = ''; foreach ( $arr as $k => $n ) { $h .= '<a href="/' . $k . '">' . $n . '</a>'; } return $h; };
			$strip = '<section id="cms-pages" style="padding:56px 20px;text-align:center;border-top:1px solid rgba(154,123,46,.28)"><style>#cms-pages .k{font:500 11px/1 Archivo,Helvetica,Arial,sans-serif;letter-spacing:.28em;text-transform:uppercase;color:#7E6424;margin:0 0 16px}#cms-pages .r{display:flex;flex-wrap:wrap;justify-content:center;gap:10px 26px;margin:0 auto 34px;max-width:900px}#cms-pages .r a{font:400 22px/1.3 "EB Garamond",Garamond,Georgia,serif;color:#1E1C18;text-decoration:none;border-bottom:1px solid transparent}#cms-pages .r a:hover{border-color:#9A7B2E}</style><p class="k">The cities</p><div class="r">' . $a( $c ) . '</div><p class="k">The work</p><div class="r">' . $a( $v ) . '</div><p class="k" style="margin:0"><a href="/about" style="color:inherit;text-decoration:none">About Charbel Msallem</a> &nbsp;·&nbsp; <a href="/journal" style="color:inherit;text-decoration:none">Journal</a></p><p style="font:italic 400 19px/1.4 \'EB Garamond\',Garamond,Georgia,serif;margin:18px 0 0"><a href="/journal/golden-ratio-couture-frame" style="color:#4A4740;text-decoration:none">From the journal: The golden ratio inside a couture frame</a></p></section>';
			$out = str_replace( '<footer class="foot">', $strip . "\n" . '<footer class="foot">', $out );
		}
		return $out;
	} );
}, -10 );

/* Sitemap: add the city pages to the CMS Site sitemap on the way out. */
add_action( 'init', function () {
	$path = '/' . ltrim( (string) wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? $_SERVER['REQUEST_URI'] : '/', PHP_URL_PATH ), '/' );
	if ( '/sitemap.xml' !== $path ) { return; }
	ob_start( function ( $out ) {
		if ( false === strpos( $out, '</urlset>' ) || false !== strpos( $out, '/beirut</loc>' ) ) { return $out; }
		$add = '';
		foreach ( array( 'beirut', 'dubai', 'paris', 'fr/paris', 'fr/joaillerie', 'milan', 'istanbul', 'barcelona', 'bridal', 'abaya', 'fr/abaya', 'ar/abaya', 'couture', 'fashion-show', 'paris-fashion-week', 'fr/paris-fashion-week', 'editorial', 'fashion-film', 'celebrities', 'fr/celebrities', 'elie-feghali-la-grace', 'elie-saab', 'about', 'lebanon-fashion-photographer', 'lookbook-photographer-beirut', 'press', 'privacy', 'behind-the-scenes', 'journal', 'journal/golden-ratio-couture-frame', 'journal/light-behind-the-embroidery', 'journal/the-night-of-the-show', 'journal/from-beirut-to-the-opera-garnier', 'aleph' ) as $c ) {
			$add .= '  <url><loc>https://charbelmsallem.net/' . $c . '</loc><lastmod>' . ( in_array( $c, array( 'about', 'lebanon-fashion-photographer', 'lookbook-photographer-beirut' ), true ) ? '2026-11-14' : '2026-11-08' ) . '</lastmod></url>' . "\n";
		}
		return str_replace( '</urlset>', $add . '</urlset>', $out );
	} );
}, -10 );

/*
 * 1.7.0 (8 Nov 2026): entity, headings and alt text, on the way out, for the home page,
 * service/jewellery pages and every city/service page above. Nothing in CMS Site is edited.
 *  - Schema: alternateName "Charbel Moussallem", full sameAs, press as subjectOf,
 *    founded 2009, studio address Bsalim (matches the Google Business Profile).
 *  - Chapter H2s get a real space between city and line ("Beirut Where…").
 *  - One written alt per frame from alts.json (keyed by file name).
 */
add_action( 'init', function () {
	if ( is_admin() || wp_doing_ajax() || wp_doing_cron() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) { return; }
	$path = trim( (string) wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? $_SERVER['REQUEST_URI'] : '/', PHP_URL_PATH ), '/' );
	$ok = array( '', 'maison-service', 'jewellery', 'beirut', 'dubai', 'paris', 'milan', 'istanbul', 'barcelona', 'bridal', 'abaya', 'fr/abaya', 'couture', 'fashion-show', 'paris-fashion-week', 'fr/paris-fashion-week', 'editorial', 'fashion-film', 'fr/paris', 'fr/joaillerie', 'celebrities', 'fr/celebrities', 'elie-feghali-la-grace', 'elie-saab', 'about', 'lebanon-fashion-photographer', 'lookbook-photographer-beirut', 'press', 'privacy', 'behind-the-scenes', 'ar/beirut', 'ar/dubai', 'ar/abaya', 'journal', 'journal/golden-ratio-couture-frame', 'journal/light-behind-the-embroidery', 'journal/the-night-of-the-show', 'journal/from-beirut-to-the-opera-garnier', 'journal/fashion-film-or-photographs-couture-launch', 'journal/choosing-a-film-director-paris-couture-campaign', 'journal/one-campaign-three-cities-choosing-the-studio', 'search', 'aleph' );
	if ( ! in_array( $path, $ok, true ) ) { return; }
	$home = ( '' === $path );
	ob_start( function ( $out ) use ( $home ) {
		if ( false === stripos( $out, '<html' ) ) { return $out; }
		// Headings: city and line read as two words.
		$out = str_replace( '</span><span class="et">', '</span> <span class="et">', $out );
		// Alt text, one per frame.
		static $alts = null;
		if ( null === $alts ) {
			$f = __DIR__ . '/alts.json';
			$alts = is_readable( $f ) ? (array) json_decode( (string) file_get_contents( $f ), true ) : array();
		}
		if ( $alts && false === strpos( $out, '<html lang="fr"' ) && false === strpos( $out, '<html lang="ar"' ) ) {
			$out = preg_replace_callback( '#<img\b[^>]*>#i', function ( $m ) use ( $alts ) {
				$tag = $m[0];
				if ( false !== strpos( $tag, 'data-alt-keep' ) ) { return $tag; } // photo index tiles keep their own written alt
				if ( ! preg_match( '#\ssrc="([^"]+)"#i', $tag, $s ) ) { return $tag; }
				$b = basename( (string) wp_parse_url( $s[1], PHP_URL_PATH ) );
				if ( empty( $alts[ $b ] ) ) { return $tag; }
				$alt = esc_attr( $alts[ $b ] );
				if ( preg_match( '#\salt="[^"]*"#i', $tag ) ) { return preg_replace( '#\salt="[^"]*"#i', ' alt="' . $alt . '"', $tag, 1 ); }
				return preg_replace( '#<img\b#i', '<img alt="' . $alt . '"', $tag, 1 );
			}, $out );
		}
		// Tracking: Google tag (GA4, GTM-KVHFHNK6) + Meta Pixel, once per page, and one event per segment on every action link.
		if ( false === strpos( $out, 'GTM-KVHFHNK6' ) && false !== stripos( $out, '</head>' ) ) {
			$px  = ( false === strpos( $out, "fbq('init'" ) && false === strpos( $out, 'fbq("init"' ) )
				? "!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,document,'script','https://connect.facebook.net/en_US/fbevents.js');fbq('init','454398224725918');fbq('track','PageView');"
				: '';
			$tag = '<script>(function(){var s=document.createElement("script");s.async=1;s.src="https://www.googletagmanager.com/gtm.js?id=GTM-KVHFHNK6";document.head.appendChild(s)})();</script>'
				. '<script>window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}gtag("js",new Date());' . $px
				. '(function(){var p=location.pathname.replace(/^\/|\/$|\.html$/g,"").replace("fr/","")||"home";'
				. 'var seg={bridal:"bridal",abaya:"abaya",couture:"couture","fashion-show":"fashion_show","paris-fashion-week":"fashion_show",editorial:"editorial","fashion-film":"fashion_film",celebrities:"celebrities",aleph:"aleph_art",jewellery:"jewellery",service:"service",about:"about",home:"home"}[p]||(p.indexOf("journal")===0?"journal":"city_"+p);'
				. 'document.addEventListener("click",function(e){var a=e.target.closest&&e.target.closest("a,button");if(!a)return;var h=(a.getAttribute("href")||"")+" "+(a.textContent||"");'
				. 'if(!/wa\.me|whatsapp|mailto:|tel:|#contact|reserve|book|concept|conversation|begin/i.test(h))return;var ev="lead_"+seg;'
				. 'var m=/wa\.me|whatsapp/i.test(h)?"whatsapp":/cal\.com|concept|book/i.test(h)?"booking":/mailto:/i.test(h)?"email":/tel:/i.test(h)?"call":"contact";try{gtag("event",ev,{link_url:a.href||"",page:p});}catch(x){}try{gtag("event","generate_lead",{method:m,segment:seg,link_url:a.href||"",page:p});}catch(x){}try{window.fbq&&fbq("trackCustom",ev,{page:p});fbq&&fbq("track","Contact");}catch(x){}},true);})();</script>';
			$out = preg_replace( '#</head>#i', $tag . '</head>', $out, 1 );
		}

		// 1.9.43: consent gate, cookie notice and the phone contact bar. Trackers load only after Accept.
		if ( false === strpos( $out, 'id="cms-cb"' ) && false !== stripos( $out, '</head>' ) && false !== stripos( $out, '</body>' ) ) {
			$gate = '<script>(function(){var H=/(clarity\.ms|connect\.facebook\.net|googletagmanager\.com|google-analytics\.com)/,q=[],ok=0;try{ok=localStorage.getItem("cms-consent")==="yes"}catch(e){}if(ok)return;var oA=Node.prototype.appendChild,oI=Node.prototype.insertBefore;function c(n){return n&&n.tagName==="SCRIPT"&&n.src&&H.test(n.src)}Node.prototype.appendChild=function(n){if(c(n)){q.push([this,n,null]);return n}return oA.call(this,n)};Node.prototype.insertBefore=function(n,r){if(c(n)){q.push([this,n,r]);return n}return oI.call(this,n,r)};window.cmsGrant=function(){try{localStorage.setItem("cms-consent","yes")}catch(e){}Node.prototype.appendChild=oA;Node.prototype.insertBefore=oI;var l=q;q=[];l.forEach(function(x){try{x[0].insertBefore(x[1],x[2]&&x[2].parentNode===x[0]?x[2]:null)}catch(e){}})};})();</script>';
			if ( preg_match( '#<head[^>]*>#i', $out, $hm ) ) { $out = preg_replace( '#<head[^>]*>#i', $hm[0] . $gate, $out, 1 ); }
			$seg = array( 'bridal' => 'bridal', 'abaya' => 'abaya', 'couture' => 'couture', 'fashion-show' => 'fashion show', 'paris-fashion-week' => 'fashion show', 'editorial' => 'editorial', 'fashion-film' => 'fashion film', 'celebrities' => 'celebrity', 'jewellery' => 'jewellery', 'press' => 'press' );
			$pp = trim( (string) wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? $_SERVER['REQUEST_URI'] : '/', PHP_URL_PATH ), '/' );
			$pp = preg_replace( '#^(fr|ar)/#', '', $pp );
			$cities = array( 'beirut' => 'Beirut', 'dubai' => 'Dubai', 'paris' => 'Paris', 'milan' => 'Milan', 'istanbul' => 'Istanbul', 'barcelona' => 'Barcelona' );
			if ( isset( $seg[ $pp ] ) ) { $what = 'a ' . $seg[ $pp ] . ' project'; }
			elseif ( isset( $cities[ $pp ] ) ) { $what = 'a shoot in ' . $cities[ $pp ]; }
			else { $what = 'a project'; }
			$wa = 'https://wa.me/9613729713?text=' . rawurlencode( 'Hello Charbel, I am writing from your website about ' . $what . '.' );
			$ui = '<div id="cms-cb" role="dialog" aria-label="Cookies" hidden><p>This website uses analytics and advertising measurement to understand how its pages are read. Nothing loads unless you accept. <a href="/privacy">Privacy</a></p><div><button type="button" id="cms-cb-y">Accept</button><button type="button" id="cms-cb-n">Decline</button></div></div>'
				. ( false !== strpos( $out, 'id="bar"' ) ? '' : '<nav id="cms-bar" aria-label="Contact"><a href="' . esc_url( $wa ) . '" rel="noopener">WhatsApp</a><a href="https://cal.com/charbelmsallem/concept-call" rel="noopener">Concept call</a></nav>' )
				. '<style>#cms-cb{position:fixed;left:0;right:0;bottom:0;z-index:99999;display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:12px 24px;padding:16px 22px;background:#F3F2EE;border-top:1px solid rgba(154,123,46,.4);font:400 16px/1.45 "EB Garamond",Georgia,serif;color:#201F1C}#cms-cb[hidden]{display:none}#cms-cb p{margin:0;max-width:760px}#cms-cb a{color:inherit}#cms-cb div{display:flex;gap:10px}#cms-cb button{font:500 11px/1 Archivo,Helvetica,Arial,sans-serif;letter-spacing:.18em;text-transform:uppercase;padding:12px 20px;border:1px solid #8B7027;background:transparent;color:#201F1C;cursor:pointer}#cms-cb-y{background:#8B7027;color:#fff}#cms-bar{display:none}@media(max-width:759px){#cms-bar{position:fixed;left:0;right:0;bottom:0;z-index:9999;display:flex;background:#F3F2EE;border-top:1px solid rgba(154,123,46,.4);padding-bottom:env(safe-area-inset-bottom)}#cms-bar a{flex:1;text-align:center;padding:16px 8px;font:500 11px/1 Archivo,Helvetica,Arial,sans-serif;letter-spacing:.2em;text-transform:uppercase;color:#201F1C;text-decoration:none}#cms-bar a+a{border-left:1px solid rgba(154,123,46,.4);background:#8B7027;color:#fff}body{padding-bottom:56px}}</style>'
				. '<script>(function(){var b=document.getElementById("cms-cb"),s=null;try{s=localStorage.getItem("cms-consent")}catch(e){}if(s==="yes"||s==="no")return;b.hidden=false;document.getElementById("cms-cb-y").onclick=function(){b.hidden=true;window.cmsGrant&&window.cmsGrant()};document.getElementById("cms-cb-n").onclick=function(){b.hidden=true;try{localStorage.setItem("cms-consent","no")}catch(e){}}})();</script>';
			$out = preg_replace( '#</body>#i', $ui . '</body>', $out, 1 );
		}
		// 1.9.17: journal feed in the head of every page; the home page also names the latest journal piece.
		if ( false === strpos( $out, 'application/rss+xml' ) && false !== stripos( $out, '</head>' ) ) {
			$add = '<link rel="alternate" type="application/rss+xml" title="Charbel Msallem Studios · Journal" href="https://charbelmsallem.net/journal/feed.xml">';
			$jf  = __DIR__ . '/pages/journal-latest.json';
			if ( $home && is_readable( $jf ) ) {
				$jl = json_decode( (string) file_get_contents( $jf ), true );
				if ( is_array( $jl ) ) { $add .= '<script type="application/ld+json">' . wp_json_encode( $jl, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . '</script>'; }
			}
			$out = preg_replace( '#</head>#i', $add . '</head>', $out, 1 );
		}
		// Structured data.
		$same = array(
			'https://www.instagram.com/charbelmsallemstudios/',
			'https://www.facebook.com/249365978439146',
			'https://www.linkedin.com/in/charbel-msallem-49669363/',
			'https://www.threads.net/@charbelmsallemstudios',
			'https://www.pinterest.com/charbelmsallem/',
			'https://www.tiktok.com/@charbelmsallemstu',
			'https://www.youtube.com/channel/UC0-dxrM_ReODRQGYZQCBHRw',
			'https://www.flickr.com/photos/95355285@N03/',
			'https://www.wikidata.org/wiki/Q142109751',
			'https://www.crunchbase.com/organization/charbel-msallem-studios',
		);
		$press = array(
			array( '@type' => 'NewsArticle', 'url' => 'https://arabic.cnn.com/style/article/2026/10/19/reem-al-jesmi-brings-emirati-heritage-to-milan', 'publisher' => array( '@type' => 'Organization', 'name' => 'CNN Arabic' ) ),
			array( '@type' => 'Article', 'url' => 'https://lofficielmonaco.com/men/the-man-the-muse-the-music-meet-aziz-abdo/', 'publisher' => array( '@type' => 'Organization', 'name' => "L'Officiel Monaco" ) ),
			array( '@type' => 'Article', 'url' => 'https://bazaarvietnam.vn/a-season-of-firsts-new-designers-step-into-milan-paris-fashion-week-studio/', 'datePublished' => '2025-12-23', 'publisher' => array( '@type' => 'Organization', 'name' => "Harper's Bazaar Vietnam" ) ),
		);
		$out = preg_replace_callback( '#(<script type="application/ld\+json">)(.*?)(</script>)#s', function ( $m ) use ( $same, $press ) {
			$d = json_decode( $m[2], true );
			if ( ! is_array( $d ) ) { return $m[0]; }
			$fix = function ( &$n ) use ( $same, $press ) {
				if ( ! is_array( $n ) ) { return; }
				$t = isset( $n['@type'] ) ? (array) $n['@type'] : array();
				$name = isset( $n['name'] ) ? $n['name'] : '';
				if ( 'Charbel Msallem Studios' === $name ) {
					$n['alternateName'] = array( 'Charbel Moussallem Studios', 'Charbel Moussallem', 'Charbel Mousallem' );
					$n['foundingDate']  = '2009';
					$n['sameAs']        = $same;
					$n['subjectOf']     = $press;
					$n['address']       = array( '@type' => 'PostalAddress', 'streetAddress' => 'Mezher main road, Gymkata building, floor -2', 'addressLocality' => 'Bsalim', 'addressRegion' => 'Mount Lebanon', 'addressCountry' => 'LB' );
				} elseif ( in_array( 'Person', $t, true ) && 'Charbel Msallem' === $name ) {
					$n['alternateName'] = array( 'Charbel Moussallem', 'Charbel Mousallem' );
					$n['sameAs']        = $same;
				}
			};
			if ( isset( $d['@graph'] ) && is_array( $d['@graph'] ) ) {
				foreach ( $d['@graph'] as &$n ) {
					$fix( $n );
					if ( isset( $n['founder'] ) ) { $fix( $n['founder'] ); }
				}
				unset( $n );
			} else {
				$fix( $d );
			}
			return $m[1] . wp_json_encode( $d, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . $m[3];
		}, $out );
		return $out;
	} );
}, -9 );

/*
 * 1.7.3: links to the home page carrying ad/tracking tags (fbclid, gclid, utm_*…) must open
 * the book, not the old WordPress home. Strip only those keys from $_GET before CMS Site
 * decides what to serve; the browser URL keeps them, so GA4 and the Pixel still read them.
 */
add_action( 'init', function () {
	$path = trim( (string) wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? $_SERVER['REQUEST_URI'] : '/', PHP_URL_PATH ), '/' );
	if ( '' !== $path || empty( $_GET ) ) { return; }
	foreach ( array_keys( $_GET ) as $k ) {
		if ( preg_match( '/^(utm_\w+|fbclid|gclid|gbraid|wbraid|msclkid|ttclid|igshid|mc_\w+|ref|cb|_ga|_gl)$/i', $k ) ) { unset( $_GET[ $k ] ); }
	}
}, -100 );

/*
 * 1.9.53: journal: three new pieces (film or photographs for a couture launch, choosing a film director for Paris couture, one campaign in three cities), in list, Blog schema, feed, sitemap and schema pass.
 * 1.9.52: /aleph page (ALEPH art editorial), in sitemap and schema pass.
 *
 * 1.9.50: copyright protection on every front-end page (16 Nov 2026, his word).
 *  - visible copyright and licensing line in the footer;
 *  - <meta name="copyright"> and noai / noimageai (search engines and assistants still read the pages);
 *  - ImageObject schema carries creator, copyrightHolder, creditText, copyrightNotice;
 *  - right-click, drag, text selection, copy and iOS long-press save are switched off (a deterrent only).
 * The photos themselves also carry the copyright inside the file (EXIF + XMP), pixels untouched.
 */
add_action( 'init', function () {
	if ( is_admin() || wp_doing_ajax() || wp_doing_cron() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) { return; }
	ob_start( function ( $out ) {
		if ( false === stripos( $out, '<html' ) || false === stripos( $out, '</head>' ) || false !== strpos( $out, 'data-cms-rights' ) ) { return $out; }
		$y      = gmdate( 'Y' );
		$notice = '© 2009–' . $y . ' Charbel Msallem Studios';
		$head   = '<meta name="copyright" content="' . $notice . '. All rights reserved.">'
			. '<meta name="robots" content="noai, noimageai">'
			. '<style data-cms-rights>img,video{-webkit-user-drag:none;-webkit-touch-callout:none}html,body{-webkit-user-select:none;user-select:none}input,textarea,[contenteditable]{-webkit-user-select:text;user-select:text}.cms-sel,.cms-sel *{-webkit-user-select:text;user-select:text}.cms-rights{max-width:70ch;margin:16px auto 0;padding:0 20px;font-size:12px;line-height:1.7;opacity:.7;text-align:center}.cms-rights a{color:inherit}</style>'
			. '<script data-cms-rights>document.addEventListener("contextmenu",function(e){var t=e.target&&e.target.tagName;if(t==="IMG"||t==="VIDEO"||t==="PICTURE"){e.preventDefault()}});function ok(n){if(n&&n.nodeType===3){n=n.parentNode}return !!(n&&n.closest&&n.closest(".cms-sel"))}function ed(e){var t=e.target;if(t&&(t.tagName==="INPUT"||t.tagName==="TEXTAREA"||t.isContentEditable)){return true}if(ok(t)){return true}var g=window.getSelection&&window.getSelection();return !!(g&&g.rangeCount&&!g.isCollapsed&&ok(g.anchorNode)&&ok(g.focusNode))}function wrap(){var w=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT,null),a=[],n;while(n=w.nextNode()){var p=n.parentNode;if(p&&!/^(SCRIPT|STYLE|NOSCRIPT|TEXTAREA)$/.test(p.tagName)&&/\+961 ?3 ?729 ?713|admin@charbelmsallem\.net/.test(n.nodeValue)){a.push(n)}}a.forEach(function(n){var f=document.createDocumentFragment(),parts=n.nodeValue.split(/(\+961 ?3 ?729 ?713|admin@charbelmsallem\.net)/);parts.forEach(function(x,i){if(i%2){var s=document.createElement("span");s.className="cms-sel";s.textContent=x;f.appendChild(s)}else if(x){f.appendChild(document.createTextNode(x))}});n.parentNode.replaceChild(f,n)})}if(document.readyState==="loading"){document.addEventListener("DOMContentLoaded",wrap)}else{wrap()}document.addEventListener("copy",function(e){if(!ed(e)){e.preventDefault()}});document.addEventListener("cut",function(e){if(!ed(e)){e.preventDefault()}});document.addEventListener("selectstart",function(e){if(!ed(e)){e.preventDefault()}});document.addEventListener("keydown",function(e){if((e.ctrlKey||e.metaKey)&&!ed(e)){var k=(e.key||"").toLowerCase();if(k==="c"||k==="x"||k==="a"||k==="s"||k==="u"){e.preventDefault()}}});document.addEventListener("dragstart",function(e){if(e.target&&e.target.tagName==="IMG"){e.preventDefault()}});</script>';
		$out  = preg_replace( '#</head>#i', $head . '</head>', $out, 1 );
		$line = '<p class="cms-rights">' . $notice . '. All photographs and films on this site are protected by copyright and may not be copied, reproduced or used without a written licence. Licensing: <a href="mailto:admin@charbelmsallem.net">admin@charbelmsallem.net</a></p>';
		$pos  = strripos( $out, '</footer>' );
		if ( false === $pos ) { $pos = strripos( $out, '</body>' ); }
		if ( false !== $pos ) { $out = substr( $out, 0, $pos ) . $line . substr( $out, $pos ); }
		// ImageObject schema: who made it and who owns it.
		$out = preg_replace_callback( '#(<script type="application/ld\+json">)(.*?)(</script>)#s', function ( $m ) use ( $notice ) {
			$d = json_decode( $m[2], true );
			if ( ! is_array( $d ) ) { return $m[0]; }
			$touched = false;
			$walk = function ( &$n ) use ( &$walk, $notice, &$touched ) {
				if ( ! is_array( $n ) ) { return; }
				if ( isset( $n['@type'] ) && in_array( 'ImageObject', (array) $n['@type'], true ) ) {
					$n['creator']         = array( '@type' => 'Person', 'name' => 'Charbel Msallem', 'url' => 'https://charbelmsallem.net/about' );
					$n['copyrightHolder'] = array( '@type' => 'Organization', 'name' => 'Charbel Msallem Studios', 'url' => 'https://charbelmsallem.net/' );
					$n['creditText']      = 'Charbel Msallem Studios';
					$n['copyrightNotice'] = $notice;
					$touched = true;
				}
				foreach ( $n as &$v ) { if ( is_array( $v ) ) { $walk( $v ); } }
			};
			$walk( $d );
			if ( ! $touched ) { return $m[0]; }
			return $m[1] . wp_json_encode( $d, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . $m[3];
		}, $out );
		return $out;
	} );
}, -10 );
