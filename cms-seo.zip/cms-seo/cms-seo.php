<?php
/**
 * Plugin Name: CMS SEO — Charbel Msallem Studios
 * Description: Keeps old 2024 WordPress addresses pointing at the new site (301) after the old pages were removed. Works beside "CMS Site". Deactivate to undo.
 * Version: 1.0.0
 * Author: Charbel Msallem Studios
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

add_action( 'template_redirect', function () {
	if ( is_user_logged_in() || is_admin() || ! is_404() ) { return; }
	$path = trim( (string) wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? $_SERVER['REQUEST_URI'] : '/', PHP_URL_PATH ), '/' );
	if ( '' === $path ) { return; }
	$first = strtolower( strtok( $path, '/' ) );
	$map = array(
		'jewelry'        => '/jewellery.html',
		'contact'        => '/#contact',
		'bookyourshoot'  => '/#contact',
		'video'          => '/#films',
		'clients'        => '/#houses',
		'about'          => '/',
		'photo-2'        => '/',
		'photo'          => '/',
		'fashion-design' => '/',
		'celebrities'    => '/',
		'makeup'         => '/',
	);
	$to = null;
	if ( isset( $map[ $first ] ) ) {
		$to = $map[ $first ];
	} elseif ( preg_match( '/^(20\d\d|category|tag|author|page|blog|_mgl\w*|[0-9a-f]{32})$/i', $first ) ) {
		$to = '/';
	}
	if ( null === $to ) { return; }
	nocache_headers();
	wp_safe_redirect( home_url( $to ), 301 );
	exit;
}, 0 );
