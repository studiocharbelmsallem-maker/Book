<?php
/**
 * Plugin Name: CMS Media — Charbel Msallem Studios
 * Description: Hosts web versions of the studio's films for charbelmsallem.net pages. No code runs.
 * Version: 1.0.0
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
