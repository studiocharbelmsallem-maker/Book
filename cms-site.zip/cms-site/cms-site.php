<?php
/**
 * Plugin Name: CMS Site — Charbel Msallem Studios
 * Description: Serves the Charbel Msallem Studios website (home, The Maison Service, the jewellery edition) on charbelmsallem.net. Deactivate to bring back the previous WordPress front page.
 * Version: 1.0.27
 * Author: Charbel Msallem Studios
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

add_action( 'init', function () {
	if ( is_admin() || wp_doing_ajax() || wp_doing_cron() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) { return; }
	$method = isset( $_SERVER['REQUEST_METHOD'] ) ? $_SERVER['REQUEST_METHOD'] : 'GET';
	if ( 'GET' !== $method && 'HEAD' !== $method ) { return; }
	$path = wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? $_SERVER['REQUEST_URI'] : '/', PHP_URL_PATH );
	$path = '/' . ltrim( (string) $path, '/' );
	// Serve the site only to visitors. Any query key that is not a known visitor/tracking
	// parameter belongs to WordPress itself (rest_route, previews, feeds, oEmbed, Jetpack, ...).
	$visitor_keys = array( 'r', 'ref', 'nc', 'v', 'tri', 'fbclid', 'gclid', 'msclkid', 'igshid', 'mc_cid', 'mc_eid' );
	foreach ( array_keys( $_GET ) as $k ) {
		if ( 0 === strpos( (string) $k, 'utm_' ) ) { continue; }
		if ( ! in_array( (string) $k, $visitor_keys, true ) ) { return; }
	}
	if ( '/' !== $path && isset( $_SERVER['HTTP_ACCEPT'] ) && false !== strpos( $_SERVER['HTTP_ACCEPT'], 'application/json' ) && false === strpos( $_SERVER['HTTP_ACCEPT'], 'text/html' ) ) { return; }
	$map = array(
		'/'               => array( 'index.html', 'text/html; charset=utf-8' ),
		'/index.html'     => array( 'index.html', 'text/html; charset=utf-8' ),
		'/service.html'   => array( 'service.html', 'text/html; charset=utf-8' ),
		'/jewellery.html' => array( 'jewellery.html', 'text/html; charset=utf-8' ),
		'/pay'           => array( 'pay.html', 'text/html; charset=utf-8' ),
		'/pay/'          => array( 'pay.html', 'text/html; charset=utf-8' ),
		'/terms'         => array( 'terms.html', 'text/html; charset=utf-8' ),
		'/terms/'        => array( 'terms.html', 'text/html; charset=utf-8' ),
		'/llms.txt'       => array( 'llms.txt', 'text/plain; charset=utf-8' ),
		'/sitemap.xml'    => array( 'sitemap.xml', 'application/xml; charset=utf-8' ),
		'/robots.txt'     => array( 'robots.txt', 'text/plain; charset=utf-8' ),
		'/og.jpg'         => array( 'og.jpg', 'image/jpeg' ),
		'/favicon.ico'    => array( 'favicon.ico', 'image/x-icon' ),
		'/favicon.svg'    => array( 'favicon.svg', 'image/svg+xml' ),
		'/apple-touch-icon.png' => array( 'apple-touch-icon.png', 'image/png' ),
		'/icon-512.png'   => array( 'icon-512.png', 'image/png' ),
		'/9e026a54605f483c9bca42c21a1900bf.txt' => array( '9e026a54605f483c9bca42c21a1900bf.txt', 'text/plain; charset=utf-8' ),
		'/google506af9a19e724330.html' => array( 'google506af9a19e724330.html', 'text/html; charset=utf-8' ),
	);
	if ( '/index.html' === $path && empty( $_GET ) ) { nocache_headers(); wp_safe_redirect( home_url( '/' ), 301 ); exit; }
	if ( ! isset( $map[ $path ] ) ) { return; }
	$file = __DIR__ . '/site/' . $map[ $path ][0];
	if ( ! is_readable( $file ) ) { return; }
	status_header( 200 );
	header( 'Content-Type: ' . $map[ $path ][1] );
	header( 'Cache-Control: public, max-age=300' );
	header( 'X-CMS-Site: 1.0.27' );
	if ( 'HEAD' !== $method ) { readfile( $file ); }
	exit;
}, 0 );

/*
 * Old 2024 WordPress front end: send visitors and search engines to the new site.
 * Old pages go to the matching section, demo posts / archives / image pages go home (301, keeps any old Google traffic).
 * Logged-in editors still see everything. Deactivate the plugin to undo.
 */
add_filter( 'wp_sitemaps_enabled', '__return_false' );
add_filter( 'jetpack_sitemap_skip_post', '__return_true' );
add_action( 'template_redirect', function () {
	if ( is_user_logged_in() || is_admin() || is_feed() || is_robots() || is_trackback() || is_preview() ) { return; }
	// Never redirect the home page to itself (that loop can be cached at the edge).
	$req = '/' . ltrim( (string) wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? $_SERVER['REQUEST_URI'] : '/', PHP_URL_PATH ), '/' );
	if ( '/' === $req || is_front_page() ) { return; }
	$home = home_url( '/' );
	$map  = array(
		'jewelry'        => '/jewellery.html',
		'contact'        => '/#contact',
		'bookyourshoot'  => '/#contact',
		'video'          => '/#films',
		'clients'        => '/#houses',
		'about'          => '/',
		'photo-2'        => '/',
		'fashion-design' => '/',
		'celebrities'    => '/',
		'makeup'         => '/',
	);
	if ( is_page() ) {
		$slug = get_post_field( 'post_name', get_queried_object_id() );
		if ( isset( $map[ $slug ] ) ) { nocache_headers(); wp_safe_redirect( home_url( $map[ $slug ] ), 301 ); exit; }
		return;
	}
	if ( is_attachment() || is_single() || is_home() || is_archive() || is_search() ) { nocache_headers(); wp_safe_redirect( $home, 301 ); exit; }
}, 1 );
