<?php
/**
 * Plugin Name: CMS Site — Charbel Msallem Studios
 * Description: Serves the Charbel Msallem Studios website (home, The Maison Service, the jewellery edition) on charbelmsallem.net. Deactivate to bring back the previous WordPress front page.
 * Version: 1.0.0
 * Author: Charbel Msallem Studios
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

add_action( 'init', function () {
	if ( is_admin() || wp_doing_ajax() || wp_doing_cron() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) { return; }
	$method = isset( $_SERVER['REQUEST_METHOD'] ) ? $_SERVER['REQUEST_METHOD'] : 'GET';
	if ( 'GET' !== $method && 'HEAD' !== $method ) { return; }
	$path = wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? $_SERVER['REQUEST_URI'] : '/', PHP_URL_PATH );
	$path = '/' . ltrim( (string) $path, '/' );
	// Leave WordPress's own previews, searches and post links alone.
	foreach ( array( 'p', 'page_id', 's', 'preview', 'feed', 'attachment_id' ) as $k ) { if ( isset( $_GET[ $k ] ) ) { return; } }
	$map = array(
		'/'               => array( 'index.html', 'text/html; charset=utf-8' ),
		'/index.html'     => array( 'index.html', 'text/html; charset=utf-8' ),
		'/service.html'   => array( 'service.html', 'text/html; charset=utf-8' ),
		'/jewellery.html' => array( 'jewellery.html', 'text/html; charset=utf-8' ),
		'/llms.txt'       => array( 'llms.txt', 'text/plain; charset=utf-8' ),
		'/sitemap.xml'    => array( 'sitemap.xml', 'application/xml; charset=utf-8' ),
		'/robots.txt'     => array( 'robots.txt', 'text/plain; charset=utf-8' ),
		'/og.jpg'         => array( 'og.jpg', 'image/jpeg' ),
	);
	if ( ! isset( $map[ $path ] ) ) { return; }
	$file = __DIR__ . '/site/' . $map[ $path ][0];
	if ( ! is_readable( $file ) ) { return; }
	status_header( 200 );
	header( 'Content-Type: ' . $map[ $path ][1] );
	header( 'Cache-Control: public, max-age=300' );
	header( 'X-CMS-Site: 1.0.0' );
	if ( 'HEAD' !== $method ) { readfile( $file ); }
	exit;
}, 0 );
