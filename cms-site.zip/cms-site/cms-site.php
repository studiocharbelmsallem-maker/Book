<?php
/**
 * Plugin Name: CMS Site — Charbel Msallem Studios
 * Description: Serves the Charbel Msallem Studios website (home, The Maison Service, the jewellery edition) on charbelmsallem.net. Deactivate to bring back the previous WordPress front page.
 * Version: 1.0.3
 * Author: Charbel Msallem Studios
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

add_action( 'init', function () {
	if ( is_admin() || wp_doing_ajax() || wp_doing_cron() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) { return; }
	$method = isset( $_SERVER['REQUEST_METHOD'] ) ? $_SERVER['REQUEST_METHOD'] : 'GET';
	if ( 'GET' !== $method && 'HEAD' !== $method ) { return; }
	$path = wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? $_SERVER['REQUEST_URI'] : '/', PHP_URL_PATH );
	$path = '/' . ltrim( (string) $path, '/' );
	// Serve the site only to visitors. Any query key that is not a known visitor/tracking
	// parameter belongs to WordPress itself (rest_route, previews, feeds, oEmbed, Jetpack, ...).
	$visitor_keys = array( 'r', 'ref', 'nc', 'v', 'tri', 'fbclid', 'gclid', 'msclkid', 'igshid', 'mc_cid', 'mc_eid' );
	foreach ( array_keys( $_GET ) as $k ) {
		if ( 0 === strpos( (string) $k, 'utm_' ) ) { continue; }
		if ( ! in_array( (string) $k, $visitor_keys, true ) ) { return; }
	}
	if ( isset( $_SERVER['HTTP_ACCEPT'] ) && false !== strpos( $_SERVER['HTTP_ACCEPT'], 'application/json' ) && false === strpos( $_SERVER['HTTP_ACCEPT'], 'text/html' ) ) { return; }
	$map = array(
		'/'               => array( 'index.html', 'text/html; charset=utf-8' ),
		'/index.html'     => array( 'index.html', 'text/html; charset=utf-8' ),
		'/service.html'   => array( 'service.html', 'text/html; charset=utf-8' ),
		'/jewellery.html' => array( 'jewellery.html', 'text/html; charset=utf-8' ),
		'/llms.txt'       => array( 'llms.txt', 'text/plain; charset=utf-8' ),
		'/sitemap.xml'    => array( 'sitemap.xml', 'application/xml; charset=utf-8' ),
		'/robots.txt'     => array( 'robots.txt', 'text/plain; charset=utf-8' ),
		'/og.jpg'         => array( 'og.jpg', 'image/jpeg' ),
	);
	if ( ! isset( $map[ $path ] ) ) { return; }
	$file = __DIR__ . '/site/' . $map[ $path ][0];
	if ( ! is_readable( $file ) ) { return; }
	status_header( 200 );
	header( 'Content-Type: ' . $map[ $path ][1] );
	header( 'Cache-Control: public, max-age=300' );
	header( 'X-CMS-Site: 1.0.3' );
	if ( 'HEAD' !== $method ) { readfile( $file ); }
	exit;
}, 0 );
