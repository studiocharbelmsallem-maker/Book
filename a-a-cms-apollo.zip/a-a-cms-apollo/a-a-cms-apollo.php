<?php
/**
 * Plugin Name: CMS Apollo Visitors
 * Description: Adds the Apollo website visitor tracker to every HTML page. Deactivate to remove it.
 * Version: 1.1.0
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
function cms_apollo_snippet() {
	return '<script>function initApollo(){var n=Math.random().toString(36).substring(7),o=document.createElement("script");o.src="https://assets.apollo.io/micro/website-tracker/tracker.iife.js?nocache="+n,o.async=!0,o.defer=!0,o.onload=function(){window.trackingFunctions.onLoad({appId:"6ae066e417fc60001c3b1440"})},document.head.appendChild(o)}initApollo();</script>';
}
( function () {
	if ( is_admin() || ( defined( 'DOING_CRON' ) && DOING_CRON ) || ( defined( 'DOING_AJAX' ) && DOING_AJAX ) ) { return; }
	$path = (string) parse_url( isset( $_SERVER['REQUEST_URI'] ) ? $_SERVER['REQUEST_URI'] : '/', PHP_URL_PATH );
	if ( 0 === strpos( $path, '/wp-' ) || false !== strpos( $path, '/xmlrpc' ) ) { return; }
	$ext = strtolower( pathinfo( $path, PATHINFO_EXTENSION ) );
	if ( '' !== $ext && 'html' !== $ext && 'htm' !== $ext && 'php' !== $ext ) { return; }
	ob_start( function ( $html ) {
		if ( false === stripos( $html, '</head>' ) || false !== strpos( $html, 'initApollo' ) ) { return $html; }
		return preg_replace( '~<head([^>]*)>~i', '<head$1>' . cms_apollo_snippet(), $html, 1 );
	} );
} )();
