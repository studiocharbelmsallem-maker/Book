<?php
/**
 * Plugin Name: CMS Reservations — signed quotations from charbelmsallem.net
 * Description: Saves every signed reservation page (serial, client details, package, amounts, signature) privately on the site, emails admin@charbelmsallem.net, and tracks the payment gates: 60% before the shoot, 40% before delivery. Deactivate to stop saving (WhatsApp sending keeps working).
 * Version: 1.0.0
 * Author: Charbel Msallem Studios
 */
if (!defined('ABSPATH')) exit;

const CMS_RES_GATES = ['signed','deposit_received','shot','delivered_preview','balance_received','released'];

add_action('init', function () {
  register_post_type('cms_reservation', [
    'label' => 'Reservations',
    'labels' => ['name' => 'Reservations', 'singular_name' => 'Reservation'],
    'public' => false, 'show_ui' => true, 'show_in_menu' => true, 'menu_icon' => 'dashicons-clipboard',
    'show_in_rest' => true, 'rest_base' => 'cms-reservations',
    'supports' => ['title','editor','custom-fields'],
    'capability_type' => 'post', 'map_meta_cap' => true,
  ]);
  $keys = ['ref','house','house_city','client_name','client_house','email','phone','address','vat','note','package','kind','currency','total','deposit','balance','window','dates','signed_by','signed_at','gate','deposit_paid_on','balance_paid_on'];
  foreach ($keys as $k) {
    register_post_meta('cms_reservation', 'cms_'.$k, [
      'type' => 'string', 'single' => true, 'show_in_rest' => true,
      'auth_callback' => function () { return current_user_can('edit_posts'); },
    ]);
  }
});

add_action('rest_api_init', function () {
  register_rest_route('cms/v1', '/reserve', [
    'methods' => 'POST',
    'permission_callback' => '__return_true',
    'callback' => function (WP_REST_Request $r) {
      $d = $r->get_json_params();
      if (!is_array($d) || !empty($d['website'])) return new WP_REST_Response(['ok' => true], 200); // honeypot
      $ip = $_SERVER['REMOTE_ADDR'] ?? '';
      $tk = 'cms_res_' . md5($ip);
      $n = (int) get_transient($tk);
      if ($n > 10) return new WP_Error('busy', 'Too many submissions', ['status' => 429]);
      set_transient($tk, $n + 1, HOUR_IN_SECONDS);
      $t = function ($k, $max = 400) use ($d) { return mb_substr(sanitize_textarea_field((string)($d[$k] ?? '')), 0, $max); };
      $ref = $t('ref', 40);
      if (!preg_match('/^CMS-Q-\d{4}-\d{3}(-[A-Z])?$/', $ref)) return new WP_Error('bad_ref', 'Unknown quotation', ['status' => 400]);
      foreach (['client_name','email','phone','signed_by'] as $req) if ($t($req) === '') return new WP_Error('missing', 'Missing '.$req, ['status' => 400]);
      $summary = $t('summary', 6000);
      $id = wp_insert_post([
        'post_type' => 'cms_reservation', 'post_status' => 'private',
        'post_title' => $ref . ' · ' . $t('house', 120) . ' · ' . $t('client_name', 120),
        'post_content' => $summary,
      ], true);
      if (is_wp_error($id)) return $id;
      foreach (['ref','house','house_city','client_name','client_house','email','phone','address','vat','note','package','kind','currency','total','deposit','balance','window','dates','signed_by','signed_at'] as $k) update_post_meta($id, 'cms_'.$k, $t($k, $k === 'address' ? 600 : 200));
      update_post_meta($id, 'cms_gate', 'signed');
      wp_mail('admin@charbelmsallem.net', 'Signed: ' . $ref . ' · ' . $t('house', 120) . ' · deposit ' . $t('deposit', 40),
        $summary . "\n\nSaved on charbelmsallem.net (Reservations #" . $id . "). Gate: signed, awaiting 60%. No shoot before the deposit; no delivery before the balance.");
      return new WP_REST_Response(['ok' => true, 'id' => $id], 201);
    },
  ]);
});
