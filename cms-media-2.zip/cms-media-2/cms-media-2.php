<?php
/**
 * Plugin Name: CMS Media 2 — Charbel Msallem Studios
 * Description: Hosts web versions of the studio's films (set 2). No code runs.
 * Version: 1.0.0
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
